import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailuser',
  templateUrl: './detailuser.page.html',
  styleUrls: ['./detailuser.page.scss'],
})
export class DetailuserPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
