import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class TrashService {

  constructor(private http: Http) { }

  createDaftar(nama_pelapor, nama_daerah, dsk) {
    return this.http.post('http://localhost:8081/api/daftar', {
      nama_pelapor,
      nama_daerah,
      dsk
    });
  }

  getDaftar() {
    return this.http.get('http://localhost:8081/api/daftar');
  }

  getSampahName(nm_sampah) {
    return this.http.get('http://localhost:8081/api/trashcare/' + nm_sampah);
  }

  deletedaftar(id_daftar) {
    return this.http.delete(`http://localhost:8081/api/daftar/${id_daftar}`);
  }

  search(nm_sampah) {
    return this.http.post('http://localhost:8081/api/trashcare/search', {
      nm_sampah
    });
  }
}
